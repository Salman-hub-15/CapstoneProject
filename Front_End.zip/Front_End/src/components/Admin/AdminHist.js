import React from 'react'
import './AdmHis.css'
import Adminnav from './Adminnav'
function Status()
{
    return(
   <>
   <Adminnav/>
    <div className="App">
    <h1 style={{textAlign:'center',marginTop:'2%',marginBottom:'2%'}}>Previous History Details</h1>
    <table>
      <thead>
      <tr>
        <th>S.No</th>
        <th>Car Model</th>
        <th>Licence Plate</th>
        <th>Duration</th>
        <th>UserName</th>
        <th>Previous User</th>
        <th>Feedback</th>
      </tr>
      </thead>
      <tbody>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        </tbody>
    </table>
  </div>
   </>
    );
}
export default Status;