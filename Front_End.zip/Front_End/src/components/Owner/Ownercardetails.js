import React from 'react'

function Ownercardetails() {
  return (
  <>
    <div>
      
      </div>
  </>
  )
}

export default Ownercardetails
